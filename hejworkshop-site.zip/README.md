# Hej!Workshop — homepage

A static rebuild of the homepage at <https://hejworkshop.com/>, matching the
original front-end's layout, typography, assets and behaviour.

## Run it

```bash
python3 .claude/serve.py
```

Then open <http://127.0.0.1:4319/>. Any static file server works — there is no
build step.

## Structure

```
index.html                     the homepage
kungens-kurva.html             Kungens Kurva location page
shanghai.html                  Livat Linkong, Shanghai location page
blog/index.html                the blog index ("News")
blog/*.html                    the six blog articles
design-system.html             design system reference
assets/css/styles.css          all product styling, no preprocessor
assets/css/design-system.css   documentation chrome for the reference page
assets/js/main.js              burger menu, scroll-spy, carousels, popups
assets/fonts/                  Lively Headline + Noto IKEA Latin
assets/images/                 photography, illustrations, social icons
assets/vendor/                 Swiper 8.4.7 (same library the original uses)
```

## Location pages

`kungens-kurva.html` rebuilds <https://hejworkshop.com/kungens-kurva>, reached
from the Kungens Kurva card on the homepage. It adds several components the
homepage does not use: product cards with pricing and a hover call to action,
a services list, a poster with a photographic cover, the video tour and floor
plan panels, and a closing contact block. Its header also carries a sign-in
link, a sign-up button and the language switcher.

Three deliberate deviations from the original, all noted here rather than
silently applied:

- **In-page nav anchors.** The original builds the location nav as
  `/#our_products`, which points at the *homepage* — where no such section
  exists — so every nav item lands you at the top of the homepage. The rebuild
  uses same-page anchors (`#our_products`) so the nav works. This is the one
  place the rebuild does not reproduce the original's markup.
- **Deferred, cookieless video embed.** The YouTube frame is created only when
  the play button is used, and loads from `youtube-nocookie.com`. Nothing
  third-party is requested for visitors who never press play.

- **Event poster padding.** Below 1500px the base poster reserves 196px of
  bottom padding for the horses illustration. The event poster replaces that
  illustration with a photographic cover, so on the original the reservation
  sits empty — 196px of dead space under the button against 40px above the
  heading. A `.poster--cover` modifier restores symmetry (40px, or 16px below
  1000px). This is the one change that alters the page height versus the
  original: the section drops from 393px to 237px at tablet widths.

One original quirk *is* reproduced: below 1000px the header's sign-up button
label wraps to two lines, making the bar 100px tall while the hero below still
offsets by only 74px — so the bar overlaps the top of the hero by 26px.

`shanghai.html` rebuilds <https://hejworkshop.com/shanghai>, reached from the
Shanghai card on the homepage. Its header carries the language switcher only —
this location has no sign-in/sign-up (the source `headerRightBlock` entry for
it doesn't define them) and no CTA button in the hero. Its "Video tour"
section has one panel, not the video/floor-plan pair Kungens Kurva has —
Shanghai's source content has no floor plan asset. Its footer drops to two
columns (no FAQ link, no socials) matching the source's shorter footer entry.

Four of the six products open a popup instead of linking out: a QR code, the
booking copy, a feature-icon row, and the original's booking form, reproduced
for layout only since it has no backend to submit to (`assets/js/main.js`
prevents the default submit). The other two open a plain "Contact us" popup.
Both popups are a single shared overlay each (`#item-popup`, `#contact-popup`)
populated from `<template>` tags next to the product that opens them, mirroring
the existing lightbox's populate-on-open pattern rather than shipping six
near-duplicate modals. The feature icons are Google's Material Symbols
Outlined glyphs (Apache-2.0), inlined as SVG paths rather than linked from
Google Fonts at runtime, to keep the project's no-third-party-requests
posture on load.

## Blog

`blog/index.html` rebuilds <https://hejworkshop.com/blog>, and the six
`blog/*.html` pages rebuild each article beneath it, all reached from the
**News** nav item or the homepage's News cards. Article bodies are converted
from the source's Contentful rich-text document (bold marks, links, bullet
lists) rather than transcribed by hand, so formatting matches the original
structurally, not just visually. Each article closes with a "Related News"
block reusing the homepage's `.article` card component with the same two (or
one, for the last two posts) related entries the source lists.

The homepage's News section only links to three of these six articles
(Swedish Chamber, Nordic Friends, Sanna Balsvik) — that was already true of
the source before this rebuild. The blog index lists all six, matching
<https://hejworkshop.com/blog> exactly.

## Design system

`design-system.html` documents the colour, typography and components the
homepage is built from, reachable from the **Design system** nav item.

It renders every example with the production `styles.css` rather than with
copied markup, so a component that breaks in the product breaks here too.
`design-system.css` only supplies the surrounding chrome — swatches, spec
tables, example stages — plus a few clearly-marked helpers that force states
you would otherwise need a pointer or a narrow viewport to see (`.menu--static`,
`.ds-button--hover`, `.burger--demo`).

Contrast ratios in the colour section are measured, not estimated. Two pairings
fall short of WCAG AA for normal text and are flagged rather than quietly
rounded up:

| Pairing | Ratio | Level |
| --- | --- | --- |
| Nav link at rest on white | 3.79:1 | AA Large only |
| Footer link hover on teal | 3.43:1 | AA Large only |

The price caption (`#767571` on white, 4.61:1) passes AA but only just, and it
is the one colour in the system with no variable behind it.

Both are inherited from the original site, so they are documented as-is rather
than silently corrected — changing them is a design decision, not a rebuild
detail.

## Notes on fidelity

Verified against the live site at 1900px, 1440px and 375px: every measured
element matches on position and size, and the total document height is
identical at all three widths on both pages.

| Page | 1900px | 1440px | 375px |
| --- | --- | --- | --- |
| Homepage | 4583px | 3752px | 6456px |
| Kungens Kurva | 5183px | 4909px | 6905px |

Kungens Kurva matches at 1900px. At 1440px and 375px it is intentionally
shorter than the original (4753px and 6725px) because of the poster padding
fix described below.

`shanghai.html` and the `blog/*.html` pages were checked the same way in
spirit — content and computed styles pulled from the live pages, then
screenshots compared side by side at desktop and mobile widths — but not
measured to the same three-breakpoint, pixel-count standard as the two pages
above.

Breakpoints follow the original's theme: **tablet** `max-width: 1500px`,
**mobile** `max-width: 1000px`.

A few behaviours are worth calling out because they are not obvious from the
markup alone:

- **Values section** renders as a three-column grid above 1500px and becomes a
  carousel at 1500px and below. `main.js` swaps between the two.
- **Both carousels** show two slides with a 60px gutter down to 1000px, then one
  full-width slide below that.
- **Box sizing** is the browser default (`content-box`). The original inherits
  normalize.css and relies on it — for example the banner's
  `width: calc(50% - 117px)` sits inside its own padding. Only the menu panel
  and the teal poster opt into `border-box`, as in the source.
- **The "More details" button** keeps the original's `<button><a></a></button>`
  structure; the source's `font-size: 18` is unitless and therefore ignored by
  the browser, so the rendered size is the inherited 16px.

Content (copy, images, article list) is a snapshot of the live site: the
homepage and Kungens Kurva as of 28 August 2026, Shanghai and the blog as of
16 September 2026. The original pulls it from Contentful at build/run time,
so it will keep moving out from under both snapshots.
