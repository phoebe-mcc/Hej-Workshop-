/* Hej!Workshop — homepage behaviour
   Mirrors the original site: off-canvas burger menu, scroll-spy nav, the
   photo-gallery carousel, and the values list switching from a grid to a
   carousel at 1500px and below. */

(function () {
  'use strict';

  var MOBILE = '(max-width: 1000px)';
  var TABLET = '(max-width: 1500px)';

  /* Product cards that open a popup are <div role="button"> rather than a
     link, so Enter/Space need wiring up by hand. */
  function bindActivate(el, handler) {
    el.addEventListener('click', handler);
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handler(e);
      }
    });
  }

  /* ---------------------------------------------------------------- Burger */
  function initBurger() {
    var burger = document.getElementById('burger');
    var menu = document.getElementById('menu');
    if (!burger || !menu) return;

    function setOpen(open) {
      burger.classList.toggle('open', open);
      menu.classList.toggle('open', open);
      burger.setAttribute('aria-expanded', String(open));
      document.body.classList.toggle('overflow-hidden', open);
    }

    burger.addEventListener('click', function () {
      setOpen(!menu.classList.contains('open'));
    });

    // Tapping a link closes the panel before the anchor scroll happens.
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) setOpen(false);
    });

    // Leaving mobile width must not strand the page in the open state.
    window.matchMedia(MOBILE).addEventListener('change', function (e) {
      if (!e.matches) setOpen(false);
    });
  }

  /* ------------------------------------------------------------ Scroll spy */
  function initScrollSpy() {
    var links = Array.prototype.slice.call(
      document.querySelectorAll('.menu a[href*="#"]')
    );
    if (!links.length) return;

    var targets = links
      .map(function (link) {
        var id = link.getAttribute('href').split('#')[1];
        var el = id && document.getElementById(id);
        return el ? { link: link, el: el } : null;
      })
      .filter(Boolean);

    if (!targets.length) return;

    function update() {
      var line = window.scrollY + window.innerHeight / 3;
      var current = null;

      targets.forEach(function (t) {
        if (t.el.offsetTop <= line) current = t;
      });

      targets.forEach(function (t) {
        t.link.classList.toggle('active', t === current);
      });
    }

    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }

  /* -------------------------------------------------------------- Carousel */
  /* Both carousels share one config: two slides with a 60px gutter from the
     tablet width up, one full-bleed slide below the mobile breakpoint. */
  function initCarousel(root) {
    if (!root || typeof Swiper === 'undefined') return null;

    return new Swiper(root.querySelector('.swiper'), {
      loop: true,
      slidesPerView: 1,
      spaceBetween: 0,
      pagination: {
        el: root.querySelector('.swiper-pagination'),
        clickable: true
      },
      navigation: {
        prevEl: root.querySelector('.swiper-prev'),
        nextEl: root.querySelector('.swiper-next')
      },
      breakpoints: {
        1001: { slidesPerView: 2, spaceBetween: 60 }
      }
    });
  }

  /* Every .custom-swiper on the page gets wired up. #values is the exception:
     it only becomes a carousel below the tablet width, so it is handled by
     initValues() instead. */
  function initCarousels() {
    document.querySelectorAll('.custom-swiper').forEach(function (root) {
      if (root.id !== 'values') initCarousel(root);
    });
    initValues();
  }

  /* --------------------------------------------- Values: grid <-> carousel */
  /* Above the tablet width the values render as a three-column grid; at
     1500px and below they collapse into the shared carousel. */
  function initValues() {
    var root = document.getElementById('values');
    if (!root) return;

    var shell = root.innerHTML;
    var cards = Array.prototype.slice.call(root.querySelectorAll('.value'));
    var mq = window.matchMedia(TABLET);
    var instance = null;

    function toGrid() {
      if (instance) {
        instance.destroy(true, true);
        instance = null;
      }
      root.className = 'item-list';
      root.textContent = '';
      cards.forEach(function (card) {
        root.appendChild(card);
      });
    }

    function toCarousel() {
      root.className = 'custom-swiper custom-swiper--values';
      root.innerHTML = shell;
      root.querySelectorAll('.swiper-slide').forEach(function (slide, i) {
        slide.textContent = '';
        slide.appendChild(cards[i]);
      });
      instance = initCarousel(root);
    }

    function sync() {
      if (mq.matches) {
        if (!instance) toCarousel();
      } else if (instance || root.classList.contains('custom-swiper')) {
        toGrid();
      }
    }

    mq.addEventListener('change', sync);
    sync();
  }

  /* ----------------------------------------------------------- Video tour */
  /* The poster image is swapped for the embed only once the play button is
     used, so no third-party frame loads on page view. */
  function initVideo() {
    var root = document.querySelector('.tour__video[data-video]');
    if (!root) return;

    var button = root.querySelector('.circle-button');
    if (!button) return;

    button.addEventListener('click', function () {
      var id = root.getAttribute('data-video');
      var frame = document.createElement('iframe');
      frame.src =
        'https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0';
      frame.title = 'Video tour';
      frame.allow =
        'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
      frame.allowFullscreen = true;
      root.textContent = '';
      root.appendChild(frame);
    });
  }

  /* ------------------------------------------------------------- Lightbox */
  function initLightbox() {
    var box = document.getElementById('lightbox');
    if (!box) return;

    var image = box.querySelector('img');
    var closeButton = box.querySelector('.lightbox__close');
    var lastFocused = null;

    function open(src, alt) {
      lastFocused = document.activeElement;
      image.src = src;
      image.alt = alt || '';
      box.hidden = false;
      document.body.classList.add('overflow-hidden');
      closeButton.focus();
    }

    function close() {
      box.hidden = true;
      image.src = '';
      document.body.classList.remove('overflow-hidden');
      if (lastFocused) lastFocused.focus();
    }

    document.querySelectorAll('[data-lightbox]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        var img = trigger.parentElement.querySelector('img');
        open(trigger.getAttribute('data-lightbox'), img ? img.alt : '');
      });
    });

    closeButton.addEventListener('click', close);

    // Clicking the backdrop closes; clicking the image itself does not.
    box.addEventListener('click', function (e) {
      if (e.target === box) close();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !box.hidden) close();
    });
  }

  /* --------------------------------------------------------- Contact popup */
  /* Shared "Contact us" card, opened by any product whose CTA is a plain
     enquiry rather than a booking (Hot Desk, Event venue on the Shanghai
     page). */
  function initContactPopup() {
    var box = document.getElementById('contact-popup');
    if (!box) return;

    var closeButton = box.querySelector('.popup__close');
    var lastFocused = null;

    function open() {
      lastFocused = document.activeElement;
      box.hidden = false;
      document.body.classList.add('overflow-hidden');
      closeButton.focus();
    }

    function close() {
      box.hidden = true;
      document.body.classList.remove('overflow-hidden');
      if (lastFocused) lastFocused.focus();
    }

    document.querySelectorAll('[data-opens-contact]').forEach(function (trigger) {
      bindActivate(trigger, open);
    });

    closeButton.addEventListener('click', close);

    box.addEventListener('click', function (e) {
      if (e.target === box) close();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !box.hidden) close();
    });
  }

  /* ------------------------------------------------------------ Item popup */
  /* Booking items (Dedicated Desk, Dedicated Office, Private office, Meeting
     room on the Shanghai page) open a two-column popup built from a
     <template> next to the card: a QR code and, on the original, a booking
     form with no backend to submit to — kept here for layout only. */
  function initItemPopups() {
    var box = document.getElementById('item-popup');
    if (!box) return;

    var mount = box.querySelector('.item-popup__mount');
    var closeButton = box.querySelector('.popup__close');
    var lastFocused = null;

    function open(templateId) {
      var tpl = document.getElementById(templateId);
      if (!tpl) return;
      lastFocused = document.activeElement;
      mount.innerHTML = '';
      mount.appendChild(tpl.content.cloneNode(true));
      box.hidden = false;
      document.body.classList.add('overflow-hidden');
      closeButton.focus();
    }

    function close() {
      box.hidden = true;
      mount.innerHTML = '';
      document.body.classList.remove('overflow-hidden');
      if (lastFocused) lastFocused.focus();
    }

    document.querySelectorAll('[data-popup]').forEach(function (trigger) {
      bindActivate(trigger, function () {
        open(trigger.getAttribute('data-popup'));
      });
    });

    closeButton.addEventListener('click', close);

    box.addEventListener('click', function (e) {
      if (e.target === box) close();
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !box.hidden) close();
    });

    // No backend to send bookings to — the form is presentational.
    mount.addEventListener('submit', function (e) {
      e.preventDefault();
    });
  }

  function init() {
    initBurger();
    initScrollSpy();
    initCarousels();
    initVideo();
    initLightbox();
    initContactPopup();
    initItemPopups();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
